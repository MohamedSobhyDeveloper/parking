package com.park.optech.parking.model;

/**
 * Created by mohamed on 20/11/2017.
 */

public class clientrepo {
    private String balance;

    public String getBalance(){
        return balance;
    }
}
