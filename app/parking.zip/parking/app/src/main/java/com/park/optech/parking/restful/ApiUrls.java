package com.park.optech.parking.restful;


public class ApiUrls {

    public static final String BASE_URL = "http://www.open-park.com/";
    public static final String API_URL = "api.php?";

}
