package com.park.optech.parking.sharedpref;

/**
 * Created by Mohamed on 07/02/2018.
 */

interface SectionTitleProvider {
    String getSectionTitle(int position);

}
