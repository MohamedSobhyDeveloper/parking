package com.park.optech.parking.soapapi;

/**
 * Created by mohamed on 22/11/2017.
 */

public class serviceurl {
    public final static String URL = "http://www.open-park.com/server.php";

    public final static String URL2= "http://www.open-park.com/soap_server.php";


}
